from .webengine import*
class Amazon(Webscraper):
    def __init__(self):

        browser.get("https://www.amazon.com")

    def search_for_products(self,search_product):
        search = browser.find_element_by_id("twotabsearchtextbox")
        search.clear()
        search.send_keys(search_product)
        search.send_keys(Keys.RETURN)
        sleep(1.5)
        results=[]
        i=1
        while i<16:
            try:
                product = browser.find_element_by_tag_name('div[data-index="{}"]'.format(i))
                picture = browser.find_element_by_tag_name('img[data-image-index="{}"]'.format(i))
                product_link = product.find_element_by_tag_name('a[class="a-link-normal a-text-normal"]')
                description= product.find_element_by_tag_name('span[class="a-size-medium a-color-base a-text-normal"]')
                try:
                    price=product.find_element_by_tag_name('span[class="a-price"]')
                    price_int = product.find_element_by_tag_name('span[class="a-price-whole"]')
                    results.append([picture.get_attribute('src'), description.text, product_link.get_attribute('href'), str(price.text),int(price_int.text),-1])
                    i+=1
                except:
                    results.append([picture.get_attribute('src'),description.text,product_link.get_attribute('href'), -1, -1,-1])
                    i+=1
                    continue
            except:
                i+=1
                continue
        return results
amazon = Amazon()
computer1_amazon = amazon.search_for_products('computer')

