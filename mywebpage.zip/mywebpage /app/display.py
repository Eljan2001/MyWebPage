class Displayer():
    
    def __init__(self, minimum_val, maximum_val, shipping_val, tapaz_val, amazon_val, aliexpress_val, search_val, des_asc, products_aliexpress, products_amazon, products_tapaz,price_cur):
        self.minimum_val = minimum_val
        self.maximum_val = maximum_val
        self.shipping_val = shipping_val
        self.tapaz_val = tapaz_val
        self.amazon_val = amazon_val
        self.aliexpress_val = aliexpress_val
        self.search_val = search_val
        self.des_asc = des_asc
        self.products_aliexpress=products_aliexpress
        self.products_amazon=products_amazon
        self.products_tapaz=products_tapaz
        self.price_cur = price_cur

    def get_minimum_val(self):
        return self.minimum_val
    
    def get_maximum_val(self):
        return self.maximum_val
    
    def get_shipping_val(self):
        return self.shipping_val
    
    def get_tapaz_val(self):
        return self.tapaz_val
    
    def get_amazon_val(self):
        return self.amazon_val
    
    def get_aliexpress_val(self):
        return self.aliexpress_val
    
    def get_search_val(self):
        return self.search_val
    
    def get_des_asc(self):
        return self.des_asc

    def get_products_aliexpress(self):
        return self.products_aliexpress

    def get_products_amazon(self):
        return self.products_amazon
    
    def get_products_tapaz(self):
        return self.products_tapaz
    def get_price_cur(self):
        return self.price_cur

