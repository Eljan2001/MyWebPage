from .webengine import*
class Aliexpress(Webscraper):
    def __init__(self):
        browser.get('https://best.aliexpress.com/?lan=en')

    def search_for_products(self,search_product):
        try:
            browser.find_element_by_tag_name('dt[class="cate-name"]').click()
            sleep(0.5)
        except:
            None
        search = browser.find_element_by_tag_name('input[id="search-key"]')
        search.clear()
        search.send_keys(search_product)
        browser.find_element_by_tag_name('input[class="search-button"]').click()
        sleep(1)
        results=[]
        i=0
        s=700
        iterator=8
        while i<16:
            try:
                product = browser.find_element_by_tag_name('div[product-index="{}"]'.format(i))
                picture = product.find_element_by_tag_name('img[class="item-img"]')
                product_link = product.find_element_by_tag_name('a[target="_blank"]')
                description= product.find_element_by_tag_name('a[class="item-title"]')
                try:
                    price=product.find_element_by_tag_name('span[class="price-current"]')
                    if price.text[5]=='.':
                        price_int = price.text[4:5]
                    if price.text[6]=='.':
                        price_int = price.text[4:6]
                    if price.text[7]=='.':
                        price_int = price.text[4:7]
                    try:
                        shipping = product.find_element_by_tag_name('span[class="shipping-value"]')
                        results.append([picture.get_attribute('src'), description.text, product_link.get_attribute('href'), price.text, int(price_int),shipping.text])
                    except:
                        results.append([picture.get_attribute('src'), description.text, product_link.get_attribute('href'), price.text, int(price_int),-1])
                    i+=1
                except:
                    try:
                        shipping = product.find_element_by_tag_name('span[class="shipping-value"]')
                        results.append([picture.get_attribute('src'),description.text,product_link.get_attribute('href'), -1, -1,shipping.text])
                    except:
                        results.append([picture.get_attribute('src'),description.text,product_link.get_attribute('href'), -1, -1,-1])
                    i+=1
                    continue
            except:
                if i==iterator:
                    browser.execute_script('window.scrollTo(0,{})'.format(s))
                    sleep(1)
                i+=1
                continue
        return results
aliexpress = Aliexpress()
computer1_aliexpress = aliexpress.search_for_products('computer')

