from .webengine import*
class Tapaz(Webscraper):
    def __init__(self):
        browser.get('https://tap.az')

    def search_for_products(self,search_product):
        search = browser.find_element_by_tag_name('input[id="keywords"]')
        search.clear()
        search.send_keys(search_product)
        search.send_keys(Keys.RETURN)
        sleep(0.5)
        results=[]
        i=0
        s=200
        browser.execute_script('window.scrollTo(0,5000)')
        sleep(0.5)
        products=browser.find_elements_by_tag_name('div[class="products-i rounded "')
        for product in products:
            if i<20:
                product_link = product.find_element_by_tag_name('a[class="products-link"]')
                description= product.find_element_by_tag_name('div[class="products-name"]')
                try:
                    price=product.find_element_by_tag_name('div[class="products-price"]')
                    price_int = product.find_element_by_tag_name('span[class="price-val"]')
                    results.append([-1, description.text, product_link.get_attribute('href'), price.text,int(price_int.text),-1])
                    i+=1
                except:
                    results.append([-1,description.text,product_link.get_attribute('href'), -1, -1,-1])
                    i+=1
                    continue
        return results
tapaz = Tapaz()
computer1_tapaz = tapaz.search_for_products('computer')

