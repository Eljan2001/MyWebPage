class Sorter:
    def __init__(self, product_list,price_cur,des_asc):
        self.products_list=product_list
        self.price_cur=price_cur
        self.des_asc=des_asc
    def sort_all(self):
        x=[]
        if self.price_cur=='Manat':
            for i in self.products_list:
                
                x=list(str(i[3]))
                x=x[:2]
                if x[0]!="$":
                    break
                x[0] = 'AZN '
                i[4] = i[4] * 1.7
                x[1] = str(round(i[4],2))
                i[3]=''

                for z in x:
                    i[3]+=z
        if self.price_cur=='Dollar':
            for i in self.products_list:
                x=list(str(i[3]))
                x=x[:2]
                if x[0]=="$":
                    break
                x[0] = '$ '
                i[4] = i[4] / 1.7
                x[1] = str(round(i[4],2))
                i[3]=''

                for z in x:
                    i[3]+=z
        if self.des_asc=="Ascending":
            self.products_list.sort(key = lambda x: x[4])
        if self.des_asc=="Descending":
            self.products_list.sort(key = lambda x: x[4])
            self.products_list.reverse()
        return self.products_list

