from selenium import*
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium import webdriver as wb
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from random import*
import os
from time import sleep
from selenium.webdriver.chrome.options import*
os.environ['MOZ_HEADLESS']='1'

browser=wb.Firefox(executable_path=GeckoDriverManager().install())

class Webscraper():
    def __init__(self):
        pass
    def search_for_products(self):
        pass
